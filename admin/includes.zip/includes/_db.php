<?php

$host      = 'localhost';
$username  = 'root';
$password  = '';
$database  = 'dedal';

$con = mysqli_connect( $host, $username, $password, $database );

if($con) {
  // echo "We are connected";
} else {
  header('Location: '.LINK_SITE.'erro.php');
  die( "Database connection failed" );
}

?>
